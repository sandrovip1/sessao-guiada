require("dotenv").config();

const { GoogleGenAI } = require("@google/genai");

console.log("====================================");
console.log(" TESTE DA API GEMINI");
console.log("====================================");

console.log(
    "GEMINI_API_KEY encontrada:",
    Boolean(process.env.GEMINI_API_KEY)
);

console.log(
    "Tamanho da chave:",
    process.env.GEMINI_API_KEY
        ? process.env.GEMINI_API_KEY.length
        : 0
);


if (!process.env.GEMINI_API_KEY) {

    console.error("");
    console.error(
        "ERRO: GEMINI_API_KEY não foi encontrada."
    );

    console.error("");
    console.error(
        "Verifique o arquivo:"
    );

    console.error(
        "backend/.env"
    );

    console.error("");

    process.exit(1);

}


const ai =
    new GoogleGenAI({

        apiKey:
            process.env.GEMINI_API_KEY

    });


async function testar() {

    try {

        console.log("");
        console.log(
            "Enviando teste para a Gemini..."
        );

        console.log("");


        const resposta =
            await ai.models.generateContent({

                model:
                    "gemini-3.8-flash",

                contents:
                    "Responda apenas: conexão funcionando."

            });


        console.log(
            "===================================="
        );

        console.log(
            " SUCESSO!"
        );

        console.log(
            "===================================="
        );

        console.log("");

        console.log(
            "Resposta da Gemini:"
        );

        console.log(
            resposta.text
        );

        console.log("");

    } catch (erro) {

        console.error(
            "===================================="
        );

        console.error(
            " ERRO NA GEMINI"
        );

        console.error(
            "===================================="
        );

        console.error("");

        console.error(
            "Mensagem:"
        );

        console.error(
            erro?.message ||
            erro
        );

        console.error("");

        console.error(
            "Erro completo:"
        );

        console.error(
            erro
        );

        console.error("");

    }

}


testar();
