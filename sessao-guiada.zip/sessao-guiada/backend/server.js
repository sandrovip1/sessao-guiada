require("dotenv").config();

const express = require("express");
const cors = require("cors");
const multer = require("multer");
const pdfParse = require("pdf-parse");
const { GoogleGenAI } = require("@google/genai");

const app = express();

const PORT = process.env.PORT || 3000;


/* =========================================
   CONFIGURAÇÕES
========================================= */

app.use(cors());

app.use(
    express.json({
        limit: "10mb"
    })
);


/* =========================================
   CONFIGURAÇÃO DA GEMINI
========================================= */

const GEMINI_API_KEY =
    process.env.GEMINI_API_KEY;

const ai =
    GEMINI_API_KEY
        ? new GoogleGenAI({
            apiKey: GEMINI_API_KEY
        })
        : null;


/* =========================================
   UPLOAD DE PDF
========================================= */

const storage =
    multer.memoryStorage();

const upload =
    multer({

        storage,

        limits: {

            fileSize:
                15 * 1024 * 1024

        },

        fileFilter:
            (req, file, cb) => {

                if (
                    file.mimetype ===
                    "application/pdf"
                ) {

                    cb(
                        null,
                        true
                    );

                } else {

                    cb(
                        new Error(
                            "Envie apenas arquivos PDF."
                        )
                    );

                }

            }

    });


/* =========================================
   FUNÇÕES AUXILIARES
========================================= */

function limparTexto(texto) {

    return String(texto || "")

        .replace(
            /\r/g,
            ""
        )

        .replace(
            /[ \t]+/g,
            " "
        )

        .replace(
            /\n{3,}/g,
            "\n\n"
        )

        .trim();

}


/* =========================================
   EMBARALHAR ARRAY
========================================= */

function embaralharArray(array) {

    const resultado =
        [...array];

    for (
        let i = resultado.length - 1;
        i > 0;
        i--
    ) {

        const j =
            Math.floor(
                Math.random() *
                (i + 1)
            );

        [
            resultado[i],
            resultado[j]
        ] = [
            resultado[j],
            resultado[i]
        ];

    }

    return resultado;

}


/* =========================================
   EMBARALHAR QUESTÃO
========================================= */

function embaralharQuestao(
    questao
) {

    if (
        !questao ||
        !Array.isArray(
            questao.alternativas
        )
    ) {

        return questao;

    }


    const respostaOriginal =
        Number(
            questao.respostaCorreta
        );


    if (
        Number.isNaN(
            respostaOriginal
        ) ||
        respostaOriginal < 0 ||
        respostaOriginal >=
            questao.alternativas.length
    ) {

        return questao;

    }


    const alternativas =
        questao.alternativas.map(
            (texto, indice) => ({

                texto,

                correta:
                    indice ===
                    respostaOriginal

            })
        );


    const embaralhadas =
        embaralharArray(
            alternativas
        );


    const novoIndiceCorreto =
        embaralhadas.findIndex(
            alternativa =>
                alternativa.correta
        );


    return {

        ...questao,

        alternativas:
            embaralhadas.map(
                alternativa =>
                    alternativa.texto
            ),

        respostaCorreta:
            novoIndiceCorreto

    };

}


/* =========================================
   EMBARALHAR MATERIAL
========================================= */

function embaralharMaterial(
    material
) {

    if (
        !material ||
        !Array.isArray(
            material.topicos
        )
    ) {

        return material;

    }


    material.topicos =
        material.topicos.map(
            topico => {

                if (
                    !Array.isArray(
                        topico.questoes
                    )
                ) {

                    return topico;

                }


                return {

                    ...topico,

                    questoes:
                        topico.questoes.map(
                            questao =>
                                embaralharQuestao(
                                    questao
                                )
                        )

                };

            }
        );


    return material;

}


/* =========================================
   EMBARALHAR QUESTÕES
========================================= */

function embaralharQuestoesDoMaterial(
    material
) {

    if (
        !material ||
        !Array.isArray(
            material.topicos
        )
    ) {

        return material;

    }


    material.topicos =
        material.topicos.map(
            topico => {

                if (
                    !Array.isArray(
                        topico.questoes
                    )
                ) {

                    return topico;

                }


                return {

                    ...topico,

                    questoes:
                        embaralharArray(
                            topico.questoes
                        )

                };

            }
        );


    return material;

}


/* =========================================
   DIVIDIR TEXTO EM TÓPICOS
========================================= */

function dividirEmTopicos(
    texto
) {

    const linhas =
        texto
            .split("\n")
            .map(
                linha =>
                    linha.trim()
            )
            .filter(
                linha =>
                    linha.length > 0
            );


    const topicos = [];

    let topicoAtual =
        null;


    for (
        const linha of linhas
    ) {

        const pareceTitulo =

            linha.length < 100 &&

            (

                /^(\d+\.|\d+\.\d+|[A-ZÁÉÍÓÚÂÊÔÃÕÇ][A-ZÁÉÍÓÚÂÊÔÃÕÇ\s]{3,})/.test(
                    linha
                )

                ||

                /^(introdução|conclusão|objetivos|conceitos|resumo|exercícios|referências)/i.test(
                    linha
                )

            );


        if (
            pareceTitulo
        ) {

            if (
                topicoAtual
            ) {

                topicos.push(
                    topicoAtual
                );

            }


            topicoAtual = {

                titulo:
                    linha,

                conteudo:
                    ""

            };

        } else {

            if (
                !topicoAtual
            ) {

                topicoAtual = {

                    titulo:
                        "Conteúdo inicial",

                    conteudo:
                        ""

                };

            }


            topicoAtual.conteudo +=
                linha + "\n";

        }

    }


    if (
        topicoAtual
    ) {

        topicos.push(
            topicoAtual
        );

    }


    return topicos.filter(
        topico =>
            topico.conteudo
                .trim()
                .length > 0
    );

}


/* =========================================
   MODO NORMAL
========================================= */

function gerarMaterialNormal(
    texto
) {

    const topicos =
        dividirEmTopicos(
            texto
        );


    if (
        topicos.length === 0
    ) {

        const material = {

            titulo:
                "Material de Estudo",

            modo:
                "normal",

            totalTopicos:
                1,

            topicos: [

                {

                    id:
                        1,

                    titulo:
                        "Conteúdo do material",

                    resumo:
                        texto.substring(
                            0,
                            2000
                        ),

                    conteudo:
                        texto,

                    questoes: [

                        {

                            pergunta:
                                "De acordo com o material enviado, qual alternativa apresenta uma informação presente no conteúdo?",

                            alternativas: [

                                texto.substring(
                                    0,
                                    500
                                ),

                                "A informação não aparece no material.",

                                "O material afirma exatamente o contrário.",

                                "Nenhuma informação pode ser extraída."

                            ],

                            respostaCorreta:
                                0,

                            explicacao:
                                "A alternativa correta foi extraída diretamente do conteúdo do PDF."

                        }

                    ]

                }

            ]

        };


        return embaralharMaterial(
            material
        );

    }


    const resultado =
        topicos.map(
            (topico, indice) => {

                const conteudo =
                    topico.conteudo.trim();


                const frases =
                    conteudo

                        .split(
                            /[.!?]\s+/
                        )

                        .map(
                            frase =>
                                frase.trim()
                        )

                        .filter(
                            frase =>
                                frase.length > 20
                        );


                const resumo =
                    frases
                        .slice(
                            0,
                            5
                        )
                        .join(
                            ". "
                        );


                const respostaCorreta =
                    frases[0] ||

                    "Consulte o conteúdo apresentado neste tópico.";


                return {

                    id:
                        indice + 1,

                    titulo:
                        topico.titulo,

                    resumo:
                        resumo ||
                        conteudo.substring(
                            0,
                            500
                        ),

                    conteudo:
                        conteudo,

                    questoes: [

                        {

                            pergunta:
                                `De acordo com o tópico "${topico.titulo}", qual alternativa apresenta uma informação correta?`,

                            alternativas: [

                                respostaCorreta,

                                "A informação apresentada não possui relação com o conteúdo estudado.",

                                "O conteúdo afirma exatamente o contrário do que foi apresentado.",

                                "Nenhuma das informações do material pode ser considerada correta."

                            ],

                            respostaCorreta:
                                0,

                            explicacao:
                                "A alternativa correta foi extraída diretamente do conteúdo do material enviado."

                        }

                    ]

                };

            }
        );


    const material = {

        titulo:
            "Material de Estudo",

        modo:
            "normal",

        totalTopicos:
            resultado.length,

        topicos:
            resultado

    };


    return embaralharMaterial(
        material
    );

}


/* =========================================
   MODO IA
========================================= */

async function gerarMaterialComIA(
    texto
) {

    if (!ai) {

        throw new Error(
            "GEMINI_API_KEY não está configurada."
        );

    }


    const prompt = `

Você é um professor especializado em criar materiais de estudo.

Analise cuidadosamente o conteúdo abaixo e transforme-o em uma sessão guiada de aprendizagem.

REGRAS:

1. Utilize somente informações presentes no material.

2. Organize o conteúdo em tópicos.

3. Crie um resumo claro para cada tópico.

4. Crie pelo menos três questões de múltipla escolha para cada tópico.

5. Cada questão deve ter quatro alternativas.

6. Informe o índice da alternativa correta, começando em zero.

7. Explique por que a alternativa correta está certa.

8. Não invente informações.

9. Escreva em português brasileiro.

10. Não coloque A), B), C) ou D) nas alternativas.

11. Retorne somente o texto de cada alternativa.

12. As questões devem ser baseadas diretamente no conteúdo fornecido.

13. Não crie questões sobre assuntos que não aparecem no material.

14. Evite criar alternativas obviamente absurdas ou muito fáceis de eliminar.

15. As quatro alternativas devem ser plausíveis sempre que o conteúdo permitir.

16. Crie questões diferentes entre si.

Retorne SOMENTE um JSON válido, sem Markdown e sem blocos de código.

Formato obrigatório:

{
  "titulo": "Título do material",
  "modo": "ia",
  "totalTopicos": 1,
  "topicos": [
    {
      "id": 1,
      "titulo": "Nome do tópico",
      "resumo": "Resumo do conteúdo",
      "conteudo": "Conteúdo estudado",
      "questoes": [
        {
          "pergunta": "Pergunta sobre o conteúdo",
          "alternativas": [
            "Primeira alternativa",
            "Segunda alternativa",
            "Terceira alternativa",
            "Quarta alternativa"
          ],
          "respostaCorreta": 0,
          "explicacao": "Explicação da resposta"
        }
      ]
    }
  ]
}

CONTEÚDO DO MATERIAL:

${texto.substring(0, 50000)}

`;


    console.log(
        "Chamando Gemini..."
    );


    /*
     * MODELO ATUALIZADO
     *
     * O modelo antigo gemini-2.5-flash
     * não está disponível para novos usuários.
     */

    const resposta =
        await ai.models.generateContent({

            model:
                "gemini-3.8-flash",

            contents:
                prompt

        });


    let conteudoResposta =
        resposta.text ||
        "";


    console.log(
        "Resposta recebida da Gemini."
    );


    conteudoResposta =
        conteudoResposta
            .replace(
                /```json/gi,
                ""
            )
            .replace(
                /```/g,
                ""
            )
            .trim();


    const inicio =
        conteudoResposta.indexOf(
            "{"
        );


    const fim =
        conteudoResposta.lastIndexOf(
            "}"
        );


    if (
        inicio === -1 ||
        fim === -1
    ) {

        throw new Error(
            "A IA não retornou um JSON válido."
        );

    }


    const jsonTexto =
        conteudoResposta.substring(
            inicio,
            fim + 1
        );


    let material;


    try {

        material =
            JSON.parse(
                jsonTexto
            );

    } catch (erro) {

        console.error(
            "JSON recebido da Gemini:"
        );

        console.error(
            conteudoResposta
        );

        throw new Error(
            "Não foi possível interpretar a resposta da IA."
        );

    }


    if (
        !Array.isArray(
            material.topicos
        )
    ) {

        throw new Error(
            "O material gerado não contém tópicos válidos."
        );

    }


    material.modo =
        "ia";


    material.totalTopicos =
        material.topicos.length;


    return embaralharMaterial(
        material
    );

}


/* =========================================
   ROTA DE ANÁLISE
========================================= */

app.post(

    "/api/analisar-material",

    upload.single("arquivo"),

    async (req, res) => {

        try {

            if (
                !req.file
            ) {

                return res.status(400).json({

                    sucesso:
                        false,

                    erro:
                        "Nenhum arquivo PDF foi enviado."

                });

            }


            const modo =
                req.body.modo ||
                "normal";


            console.log("");
            console.log(
                "===================================="
            );

            console.log(
                "PDF recebido:",
                req.file.originalname
            );

            console.log(
                "Modo:",
                modo
            );


            /* =================================
               EXTRAIR TEXTO
            ================================= */

            const pdf =
                await pdfParse(
                    req.file.buffer
                );


            const texto =
                limparTexto(
                    pdf.text || ""
                );


            if (
                !texto
            ) {

                return res.status(400).json({

                    sucesso:
                        false,

                    erro:
                        "Não foi possível encontrar texto no PDF. Verifique se o PDF contém texto selecionável."

                });

            }


            console.log(
                "Texto extraído:",
                texto.length,
                "caracteres"
            );


            let material;


            /* =================================
               IA
            ================================= */

            if (
                modo === "ia"
            ) {

                console.log(
                    "Modo IA selecionado."
                );

                console.log(
                    "IA configurada:",
                    Boolean(ai)
                );


                material =
                    await gerarMaterialComIA(
                        texto
                    );

            }


            /* =================================
               NORMAL
            ================================= */

            else {

                console.log(
                    "Modo normal selecionado."
                );


                material =
                    gerarMaterialNormal(
                        texto
                    );

            }


            material =
                embaralharQuestoesDoMaterial(
                    material
                );


            console.log(
                "Material gerado com sucesso."
            );


            return res.json({

                sucesso:
                    true,

                mensagem:
                    "Material analisado com sucesso.",

                material:
                    material

            });

        } catch (erro) {

            console.error("");
            console.error(
                "===================================="
            );

            console.error(
                " ERRO TÉCNICO"
            );

            console.error(
                "===================================="
            );

            console.error(
                erro
            );

            console.error(
                "Mensagem:",
                erro?.message
            );


            const mensagemErro =
                String(
                    erro?.message ||
                    ""
                );


            const erroAutenticacao =

                mensagemErro.includes(
                    "401"
                )

                ||

                mensagemErro.includes(
                    "UNAUTHENTICATED"
                )

                ||

                mensagemErro.includes(
                    "API key"
                )

                ||

                mensagemErro.includes(
                    "API_KEY"
                )

                ||

                mensagemErro.includes(
                    "invalid authentication"
                );


            if (
                erroAutenticacao
            ) {

                return res.status(401).json({

                    sucesso:
                        false,

                    codigo:
                        "IA_ACESSO_EXPIRADO",

                    erro:
                        "A chave da IA é inválida, expirou ou não possui autorização para usar o modelo Gemini."

                });

            }


            return res.status(500).json({

                sucesso:
                    false,

                erro:
                    mensagemErro ||
                    "Não foi possível analisar o material no momento."

            });

        }

    }

);


/* =========================================
   STATUS
========================================= */

app.get(
    "/api/status",
    (req, res) => {

        res.json({

            online:
                true,

            mensagem:
                "Servidor da Sessão Guiada está funcionando.",

            iaConfigurada:
                Boolean(
                    process.env.GEMINI_API_KEY
                )

        });

    }
);


/* =========================================
   ERROS DO MULTER
========================================= */

app.use(
    (
        erro,
        req,
        res,
        next
    ) => {

        console.error(
            "Erro no servidor:",
            erro
        );


        if (
            erro instanceof
            multer.MulterError
        ) {

            return res.status(400).json({

                sucesso:
                    false,

                erro:
                    "Erro no envio do arquivo."

            });

        }


        if (
            erro?.message ===
            "Envie apenas arquivos PDF."
        ) {

            return res.status(400).json({

                sucesso:
                    false,

                erro:
                    "Envie apenas arquivos PDF."

            });

        }


        return res.status(500).json({

            sucesso:
                false,

            erro:
                erro?.message ||
                "Ocorreu um erro inesperado no servidor."

        });

    }
);


/* =========================================
   INICIAR SERVIDOR
========================================= */

app.listen(
    PORT,
    () => {

        console.log("");
        console.log(
            "===================================="
        );

        console.log(
            " SESSÃO GUIADA — BACKEND"
        );

        console.log(
            "===================================="
        );

        console.log(
            `Servidor: http://localhost:${PORT}`
        );

        console.log(
            `Status: http://localhost:${PORT}/api/status`
        );

        console.log(
            `IA configurada: ${Boolean(
                process.env.GEMINI_API_KEY
            )}`
        );

        console.log(
            "===================================="
        );

    }
);
