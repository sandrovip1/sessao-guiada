// ============================================================
// SESSÃO GUIADA V3
// MATERIAIS + SESSÃO ADAPTATIVA
// ============================================================


// ============================================================
// CONFIGURAÇÕES
// ============================================================

let tempoSelecionado = 30;

let tempoInicial = 30 * 60;

let tempoRestante = 30 * 60;

let intervaloCronometro = null;


// Sessão

let questaoAtual = 0;

let respostaSelecionada = null;

let respondida = false;


// Desempenho

let acertos = 0;

let erros = 0;


// Nível

let nivelAtual = "Diagnóstico";


// Histórico

let historicoDecisoes = [];


// Conceitos

let desempenhoConceitos = {};


// Materiais

let arquivosSelecionados = [];


// ============================================================
// QUESTÕES DEMONSTRATIVAS
// ============================================================
//
// Nesta versão elas continuam locais.
// Na próxima etapa vamos substituir este bloco por
// questões/conceitos extraídos dos materiais reais.
//

const questoes = [

    {
        pergunta:
            "Qual é o resultado de 2x + 4 quando x = 3?",

        alternativas: [
            "A) 6",
            "B) 8",
            "C) 10",
            "D) 12"
        ],

        correta: 2,

        conceito:
            "Substituição de valores",

        dificuldade:
            "Fácil",

        tipo:
            "DIAGNÓSTICO"
    },


    {
        pergunta:
            "Se f(x) = x², qual é o valor de f(4)?",

        alternativas: [
            "A) 8",
            "B) 12",
            "C) 16",
            "D) 20"
        ],

        correta: 2,

        conceito:
            "Funções",

        dificuldade:
            "Fácil",

        tipo:
            "APLICAÇÃO"
    },


    {
        pergunta:
            "Qual é a derivada de f(x) = x²?",

        alternativas: [
            "A) x",
            "B) 2x",
            "C) x²",
            "D) 2"
        ],

        correta: 1,

        conceito:
            "Derivadas",

        dificuldade:
            "Médio",

        tipo:
            "APLICAÇÃO"
    },


    {
        pergunta:
            "Qual é o resultado de 5 × 6?",

        alternativas: [
            "A) 20",
            "B) 25",
            "C) 30",
            "D) 35"
        ],

        correta: 2,

        conceito:
            "Multiplicação",

        dificuldade:
            "Fácil",

        tipo:
            "VERIFICAÇÃO"
    },


    {
        pergunta:
            "Se x + 7 = 12, qual é o valor de x?",

        alternativas: [
            "A) 3",
            "B) 4",
            "C) 5",
            "D) 6"
        ],

        correta: 2,

        conceito:
            "Equação de primeiro grau",

        dificuldade:
            "Médio",

        tipo:
            "VERIFICAÇÃO"
    }

];


// ============================================================
// ELEMENTOS
// ============================================================

const inicio =
    document.getElementById("inicio");

const preparacao =
    document.getElementById("preparacao");

const sessao =
    document.getElementById("sessao");

const telaFinal =
    document.getElementById("final");


const materiaInput =
    document.getElementById("materia");

const objetivoInput =
    document.getElementById("objetivo");

const arquivoInput =
    document.getElementById("arquivo");

const listaArquivos =
    document.getElementById("lista-arquivos");


const botaoComecar =
    document.getElementById("comecar");


const cronometro =
    document.getElementById("cronometro");

const tempoLateral =
    document.getElementById("tempo-lateral");

const barraTempo =
    document.getElementById("barra-tempo");

const tempoMensagem =
    document.getElementById("tempo-mensagem");


const materiaisContador =
    document.getElementById(
        "materiais-contador"
    );

const materiaisSessao =
    document.getElementById(
        "materiais-sessao"
    );


const progressoPercentual =
    document.getElementById(
        "progresso-percentual"
    );

const barraProgresso =
    document.getElementById(
        "barra-progresso"
    );

const questoesFeitas =
    document.getElementById(
        "questoes-feitas"
    );

const questoesTotal =
    document.getElementById(
        "questoes-total"
    );


const acertosElemento =
    document.getElementById("acertos");

const errosElemento =
    document.getElementById("erros");

const precisaoElemento =
    document.getElementById("precisao");


const conceitoAtual =
    document.getElementById(
        "conceito-atual"
    );

const conceitoStatus =
    document.getElementById(
        "conceito-status"
    );


const nivelAtualElemento =
    document.getElementById(
        "nivel-atual"
    );

const nivelDescricao =
    document.getElementById(
        "nivel-descricao"
    );


const historico =
    document.getElementById(
        "historico"
    );

const historicoContador =
    document.getElementById(
        "historico-contador"
    );


const objetivoSessao =
    document.getElementById(
        "objetivo-sessao"
    );


const mensagemSistema =
    document.getElementById(
        "mensagem-sistema"
    );


const tipoQuestao =
    document.getElementById(
        "tipo-questao"
    );

const numeroQuestao =
    document.getElementById(
        "numero-questao"
    );


const pergunta =
    document.getElementById(
        "pergunta"
    );


const alternativas =
    document.getElementById(
        "alternativas"
    );


const responder =
    document.getElementById(
        "responder"
    );


const resultado =
    document.getElementById(
        "resultado"
    );

const resultadoIcone =
    document.getElementById(
        "resultado-icone"
    );

const resultadoTitulo =
    document.getElementById(
        "resultado-titulo"
    );

const resultadoTexto =
    document.getElementById(
        "resultado-texto"
    );


const proximoContainer =
    document.getElementById(
        "proximo-container"
    );

const proximoPasso =
    document.getElementById(
        "proximo-passo"
    );


const continuar =
    document.getElementById(
        "continuar"
    );


const novaSessao =
    document.getElementById(
        "nova-sessao"
    );


const finalAcertos =
    document.getElementById(
        "final-acertos"
    );

const finalErros =
    document.getElementById(
        "final-erros"
    );

const finalPrecisao =
    document.getElementById(
        "final-precisao"
    );


const diagnosticoConceitos =
    document.getElementById(
        "diagnostico-conceitos"
    );


const finalMateriaisLista =
    document.getElementById(
        "final-materiais-lista"
    );


const materiaisBannerTexto =
    document.getElementById(
        "materiais-banner-texto"
    );


// ============================================================
// TEMPO
// ============================================================

document
    .querySelectorAll(".tempo")
    .forEach(botao => {

        botao.addEventListener(
            "click",
            () => {

                document
                    .querySelectorAll(".tempo")
                    .forEach(item => {

                        item.classList.remove(
                            "ativo"
                        );

                    });


                botao.classList.add(
                    "ativo"
                );


                tempoSelecionado =
                    Number(
                        botao.dataset.tempo
                    );

            }
        );

    });


// ============================================================
// UPLOAD
// ============================================================

arquivoInput.addEventListener(
    "change",
    () => {

        const novosArquivos =
            Array.from(
                arquivoInput.files
            );


        novosArquivos.forEach(
            arquivo => {

                const jaExiste =
                    arquivosSelecionados.some(
                        item =>
                            item.name ===
                            arquivo.name &&
                            item.size ===
                            arquivo.size
                    );


                if (!jaExiste) {

                    arquivosSelecionados.push(
                        arquivo
                    );

                }

            }
        );


        arquivoInput.value =
            "";


        renderizarArquivos();

    }
);


// ============================================================
// RENDERIZAR ARQUIVOS
// ============================================================

function renderizarArquivos() {

    if (
        arquivosSelecionados.length === 0
    ) {

        listaArquivos.innerHTML = `

            <div class="sem-arquivos">
                Nenhum material adicionado.
            </div>

        `;

        return;
    }


    listaArquivos.innerHTML =
        arquivosSelecionados
            .map(
                (arquivo, index) => {

                    return `

                        <div class="arquivo-item">

                            <div class="arquivo-info">

                                <div class="arquivo-icone">
                                    PDF
                                </div>

                                <div>

                                    <div class="arquivo-nome">
                                        ${escaparHTML(
                                            arquivo.name
                                        )}
                                    </div>

                                    <div class="arquivo-tamanho">
                                        ${formatarTamanho(
                                            arquivo.size
                                        )}
                                    </div>

                                </div>

                            </div>

                            <button
                                type="button"
                                class="remover-arquivo"
                                data-index="${index}"
                            >
                                ×
                            </button>

                        </div>

                    `;

                }
            )
            .join("");


    document
        .querySelectorAll(
            ".remover-arquivo"
        )
        .forEach(botao => {

            botao.addEventListener(
                "click",
                () => {

                    const index =
                        Number(
                            botao.dataset.index
                        );


                    arquivosSelecionados.splice(
                        index,
                        1
                    );


                    renderizarArquivos();

                }
            );

        });

}


// ============================================================
// FORMATAÇÃO
// ============================================================

function formatarTamanho(bytes) {

    if (
        bytes < 1024
    ) {

        return `${bytes} B`;

    }


    if (
        bytes < 1024 * 1024
    ) {

        return `${(
            bytes / 1024
        ).toFixed(1)} KB`;

    }


    return `${(
        bytes /
        (1024 * 1024)
    ).toFixed(1)} MB`;

}


// ============================================================
// SEGURANÇA BÁSICA PARA TEXTO
// ============================================================

function escaparHTML(texto) {

    return texto
        .replace(
            /&/g,
            "&amp;"
        )
        .replace(
            /</g,
            "&lt;"
        )
        .replace(
            />/g,
            "&gt;"
        )
        .replace(
            /"/g,
            "&quot;"
        )
        .replace(
            /'/g,
            "&#039;"
        );

}


// ============================================================
// COMEÇAR
// ============================================================

botaoComecar.addEventListener(
    "click",
    iniciarPreparacao
);


function iniciarPreparacao() {

    const materia =
        materiaInput.value.trim();

    const objetivo =
        objetivoInput.value.trim();


    if (!materia) {

        alert(
            "Digite o que você precisa estudar."
        );

        materiaInput.focus();

        return;
    }


    if (!objetivo) {

        alert(
            "Digite qual é o seu objetivo."
        );

        objetivoInput.focus();

        return;
    }


    // Reset

    questaoAtual = 0;

    respostaSelecionada = null;

    respondida = false;

    acertos = 0;

    erros = 0;

    nivelAtual = "Diagnóstico";

    historicoDecisoes = [];

    desempenhoConceitos = [];


    tempoInicial =
        tempoSelecionado * 60;

    tempoRestante =
        tempoInicial;


    // Esconder início

    inicio.classList.add(
        "escondida"
    );


    // Mostrar preparação

    preparacao.classList.remove(
        "escondida"
    );


    prepararAnimacao();

}


// ============================================================
// PREPARAÇÃO
// ============================================================

function prepararAnimacao() {

    const texto =
        document.getElementById(
            "texto-preparacao"
        );


    const diagnostico =
        document.getElementById(
            "etapa-diagnostico"
        );


    texto.textContent =
        arquivosSelecionados.length > 0
            ? `Recebemos ${arquivosSelecionados.length} material(is). Preparando sua sessão.`
            : "Nenhum arquivo foi enviado. Preparando uma sessão demonstrativa.";


    diagnostico.classList.add(
        "pendente"
    );


    setTimeout(
        () => {

            texto.textContent =
                "Organizando o contexto da avaliação...";

        },
        800
    );


    setTimeout(
        () => {

            texto.textContent =
                "Definindo o ponto de partida...";

            diagnostico.classList.remove(
                "pendente"
            );

            diagnostico.innerHTML =
                "<span>✓</span> Diagnóstico preparado";

        },
        1600
    );


    setTimeout(
        () => {

            iniciarSessao();

        },
        2300
    );

}


// ============================================================
// INICIAR SESSÃO
// ============================================================

function iniciarSessao() {

    preparacao.classList.add(
        "escondida"
    );


    sessao.classList.remove(
        "escondida"
    );


    objetivoSessao.textContent =
        objetivoInput.value.trim();


    tempoInicial =
        tempoSelecionado * 60;

    tempoRestante =
        tempoInicial;


    atualizarCronometro();

    atualizarDesempenho();

    atualizarNivel();

    renderizarHistorico();

    renderizarMateriaisSessao();


    if (
        arquivosSelecionados.length > 0
    ) {

        materiaisBannerTexto.textContent =
            `${arquivosSelecionados.length} material(is) associado(s) à sessão.`;

    }

    else {

        materiaisBannerTexto.textContent =
            "Sessão demonstrativa sem materiais enviados.";

    }


    carregarQuestao();


    adicionarHistorico(
        "acao",
        "Sessão iniciada",
        "O sistema começou pelo diagnóstico."
    );


    iniciarCronometro();

}


// ============================================================
// MATERIAIS DA SESSÃO
// ============================================================

function renderizarMateriaisSessao() {

    materiaisContador.textContent =
        arquivosSelecionados.length;


    if (
        arquivosSelecionados.length === 0
    ) {

        materiaisSessao.innerHTML = `

            <div class="historico-vazio">
                Nenhum material enviado.
            </div>

        `;

        return;
    }


    materiaisSessao.innerHTML =
        arquivosSelecionados
            .slice(0, 4)
            .map(
                arquivo => {

                    return `

                        <div class="material-mini">

                            <div class="material-mini-icone">
                                PDF
                            </div>

                            <div class="material-mini-nome">
                                ${escaparHTML(
                                    arquivo.name
                                )}
                            </div>

                        </div>

                    `;

                }
            )
            .join("");

}


// ============================================================
// CARREGAR QUESTÃO
// ============================================================

function carregarQuestao() {

    if (
        questaoAtual >=
        questoes.length
    ) {

        terminarSessao();

        return;
    }


    const questao =
        questoes[questaoAtual];


    respostaSelecionada =
        null;

    respondida =
        false;


    pergunta.textContent =
        questao.pergunta;


    tipoQuestao.textContent =
        questao.tipo;


    numeroQuestao.textContent =
        `QUESTÃO ${questaoAtual + 1}`;


    conceitoAtual.textContent =
        questao.conceito;


    conceitoStatus.textContent =
        "Em avaliação";


    nivelAtual =
        questaoAtual === 0
            ? "Diagnóstico"
            : nivelAtual;


    atualizarNivel();


    const progresso =
        Math.round(
            (questaoAtual /
                questoes.length) *
                100
        );


    barraProgresso.style.width =
        `${progresso}%`;


    progressoPercentual.textContent =
        `${progresso}%`;


    questoesFeitas.textContent =
        questaoAtual;


    questoesTotal.textContent =
        questoes.length;


    if (
        questaoAtual === 0
    ) {

        mensagemSistema.textContent =
            arquivosSelecionados.length > 0
                ? "Você enviou seus materiais. Vamos começar pelo diagnóstico e usar seus resultados para decidir os próximos passos."
                : "Vamos começar pelo diagnóstico. Resolva a questão abaixo sem consultar o material.";

    }

    else {

        mensagemSistema.textContent =
            "Seu resultado anterior foi considerado. Agora vamos testar outro conceito.";

    }


    alternativas.innerHTML =
        "";


    questao.alternativas.forEach(
        (texto, index) => {

            const botao =
                document.createElement(
                    "button"
                );


            botao.type =
                "button";


            botao.className =
                "alternativa";


            botao.textContent =
                texto;


            botao.addEventListener(
                "click",
                () => {

                    selecionarAlternativa(
                        index,
                        botao
                    );

                }
            );


            alternativas.appendChild(
                botao
            );

        }
    );


    responder.disabled =
        true;


    responder.textContent =
        "Responder";


    resultado.className =
        "resultado escondido";


    proximoContainer.classList.add(
        "escondido"
    );


    continuar.classList.add(
        "escondido"
    );

}


// ============================================================
// SELECIONAR
// ============================================================

function selecionarAlternativa(
    index,
    botao
) {

    if (respondida) {
        return;
    }


    respostaSelecionada =
        index;


    document
        .querySelectorAll(
            ".alternativa"
        )
        .forEach(item => {

            item.classList.remove(
                "selecionada"
            );

        });


    botao.classList.add(
        "selecionada"
    );


    responder.disabled =
        false;

}


// ============================================================
// RESPONDER
// ============================================================

responder.addEventListener(
    "click",
    avaliarResposta
);


function avaliarResposta() {

    if (
        respostaSelecionada === null ||
        respondida
    ) {

        return;
    }


    respondida =
        true;


    const questao =
        questoes[questaoAtual];


    const acertou =
        respostaSelecionada ===
        questao.correta;


    if (
        !desempenhoConceitos[
            questao.conceito
        ]
    ) {

        desempenhoConceitos[
            questao.conceito
        ] = {

            acertos: 0,

            erros: 0

        };

    }


    const botoes =
        document.querySelectorAll(
            ".alternativa"
        );


    botoes[
        questao.correta
    ].classList.add(
        "correta"
    );


    // ========================================================
    // ACERTO
    // ========================================================

    if (acertou) {

        acertos++;


        desempenhoConceitos[
            questao.conceito
        ].acertos++;


        atualizarDesempenho();


        conceitoStatus.textContent =
            "Demonstrado";


        nivelAtual =
            questaoAtual === 0
                ? "Intermediário"
                : "Avançando";


        nivelDescricao.textContent =
            "O sistema aumentou o desafio.";


        atualizarNivel();


        adicionarHistorico(
            "acerto",
            `Questão ${questaoAtual + 1} · Acertou`,
            `${questao.conceito} demonstrado.`
        );


        resultado.className =
            "resultado certo";


        resultadoIcone.textContent =
            "✓";


        resultadoTitulo.textContent =
            "Muito bem!";


        resultadoTexto.textContent =
            `Você demonstrou domínio em ${questao.conceito}.`;


        mensagemSistema.textContent =
            "O resultado foi positivo. O sistema decidiu avançar.";


        proximoPasso.textContent =
            "Aumentar o desafio e testar outro conceito.";


        proximoContainer.classList.remove(
            "escondido"
        );


        continuar.classList.remove(
            "escondido"
        );


        responder.disabled =
            true;

    }


    // ========================================================
    // ERRO
    // ========================================================

    else {

        erros++;


        desempenhoConceitos[
            questao.conceito
        ].erros++;


        atualizarDesempenho();


        conceitoStatus.textContent =
            "Precisa de revisão";


        nivelAtual =
            "Revisão";


        nivelDescricao.textContent =
            "O sistema identificou uma dificuldade.";


        atualizarNivel();


        botoes[
            respostaSelecionada
        ].classList.add(
            "errada"
        );


        adicionarHistorico(
            "erro",
            `Questão ${questaoAtual + 1} · Erro`,
            `${questao.conceito} precisa de revisão.`
        );


        resultado.className =
            "resultado errado";


        resultadoIcone.textContent =
            "!";


        resultadoTitulo.textContent =
            "Vamos revisar este conceito.";


        resultadoTexto.textContent =
            `Você teve dificuldade em ${questao.conceito}.`;


        mensagemSistema.textContent =
            "Em vez de avançar, o sistema decidiu voltar ao conceito que apresentou dificuldade.";


        proximoPasso.textContent =
            "Revisar o conceito e tentar novamente.";


        proximoContainer.classList.remove(
            "escondido"
        );


        continuar.classList.remove(
            "escondido"
        );


        responder.disabled =
            true;

    }

}


// ============================================================
// CONTINUAR
// ============================================================

continuar.addEventListener(
    "click",
    continuarSessao
);


function continuarSessao() {

    const questao =
        questoes[questaoAtual];


    const acertou =
        respostaSelecionada ===
        questao.correta;


    if (acertou) {

        adicionarHistorico(
            "acao",
            "Decisão adaptativa",
            "O sistema decidiu avançar para outro conceito."
        );


        questaoAtual++;


        if (
            questaoAtual >=
            questoes.length
        ) {

            terminarSessao();

            return;
        }


        carregarQuestao();

        return;
    }


    // ========================================================
    // REVISÃO
    // ========================================================

    mensagemSistema.textContent =
        "Agora faça uma nova tentativa. O sistema quer verificar se a revisão resolveu a dificuldade.";


    conceitoStatus.textContent =
        "Nova tentativa";


    nivelAtual =
        "Revisão";


    nivelDescricao.textContent =
        "Verificando recuperação do conceito.";


    atualizarNivel();


    resultado.className =
        "resultado escondido";


    proximoContainer.classList.add(
        "escondido"
    );


    continuar.classList.add(
        "escondido"
    );


    document
        .querySelectorAll(
            ".alternativa"
        )
        .forEach(botao => {

            botao.classList.remove(
                "errada",
                "correta",
                "selecionada"
            );

        });


    respostaSelecionada =
        null;


    respondida =
        false;


    responder.disabled =
        true;


    adicionarHistorico(
        "acao",
        "Revisão iniciada",
        `Nova tentativa em ${questao.conceito}.`
    );

}


// ============================================================
// NÍVEL
// ============================================================

function atualizarNivel() {

    nivelAtualElemento.textContent =
        nivelAtual;

}


// ============================================================
// CRONÔMETRO
// ============================================================

function iniciarCronometro() {

    clearInterval(
        intervaloCronometro
    );


    intervaloCronometro =
        setInterval(
            () => {

                tempoRestante--;

                atualizarCronometro();


                if (
                    tempoRestante <= 0
                ) {

                    clearInterval(
                        intervaloCronometro
                    );


                    terminarSessao();

                }

            },
            1000
        );

}


// ============================================================
// ATUALIZAR CRONÔMETRO
// ============================================================

function atualizarCronometro() {

    const minutos =
        Math.floor(
            tempoRestante / 60
        );


    const segundos =
        tempoRestante % 60;


    const texto =
        `${String(minutos).padStart(2, "0")}:${String(segundos).padStart(2, "0")}`;


    cronometro.textContent =
        texto;


    tempoLateral.textContent =
        texto;


    const porcentagem =
        Math.max(
            0,
            (tempoRestante /
                tempoInicial) *
                100
        );


    barraTempo.style.width =
        `${porcentagem}%`;


    if (
        porcentagem <= 25
    ) {

        barraTempo.style.background =
            "#e5484d";


        tempoMensagem.textContent =
            "Pouco tempo restante. Priorizando decisões rápidas.";

    }

    else if (
        porcentagem <= 50
    ) {

        barraTempo.style.background =
            "#f59e0b";


        tempoMensagem.textContent =
            "Metade da sessão já passou. O sistema está priorizando os pontos importantes.";

    }

    else {

        barraTempo.style.background =
            "#635bff";


        tempoMensagem.textContent =
            "Você está no início da sessão.";

    }

}


// ============================================================
// DESEMPENHO
// ============================================================

function atualizarDesempenho() {

    acertosElemento.textContent =
        acertos;


    errosElemento.textContent =
        erros;


    const total =
        acertos + erros;


    const precisao =
        total === 0
            ? 0
            : Math.round(
                (acertos /
                    total) *
                    100
            );


    precisaoElemento.textContent =
        `${precisao}%`;

}


// ============================================================
// HISTÓRICO
// ============================================================

function adicionarHistorico(
    tipo,
    titulo,
    descricao
) {

    historicoDecisoes.unshift({

        tipo,

        titulo,

        descricao

    });


    renderizarHistorico();

}


// ============================================================
// RENDERIZAR HISTÓRICO
// ============================================================

function renderizarHistorico() {

    historicoContador.textContent =
        historicoDecisoes.length;


    if (
        historicoDecisoes.length === 0
    ) {

        historico.innerHTML = `

            <div class="historico-vazio">
                As decisões tomadas durante a
                sessão aparecerão aqui.
            </div>

        `;

        return;
    }


    historico.innerHTML =
        historicoDecisoes
            .slice(0, 8)
            .map(item => {

                let icone =
                    "→";

                let classe =
                    "acao";


                if (
                    item.tipo ===
                    "acerto"
                ) {

                    icone =
                        "✓";

                    classe =
                        "acerto";

                }


                if (
                    item.tipo ===
                    "erro"
                ) {

                    icone =
                        "!";

                    classe =
                        "erro";

                }


                return `

                    <div class="historico-item">

                        <div
                            class="historico-icone ${classe}"
                        >
                            ${icone}
                        </div>

                        <div class="historico-texto">

                            <strong>
                                ${item.titulo}
                            </strong>

                            <span>
                                ${item.descricao}
                            </span>

                        </div>

                    </div>

                `;

            })
            .join("");

}


// ============================================================
// DIAGNÓSTICO FINAL
// ============================================================

function renderizarDiagnosticoFinal() {

    const conceitos =
        Object.entries(
            desempenhoConceitos
        );


    if (
        conceitos.length === 0
    ) {

        diagnosticoConceitos.innerHTML = `
            <div class="historico-vazio">
                Nenhum conceito foi avaliado.
            </div>
        `;

        return;
    }


    diagnosticoConceitos.innerHTML =
        conceitos
            .map(
                ([conceito, dados]) => {

                    const total =
                        dados.acertos +
                        dados.erros;


                    const precisao =
                        total === 0
                            ? 0
                            : Math.round(
                                (dados.acertos /
                                    total) *
                                    100
                            );


                    let status =
                        "parcial";


                    let texto =
                        "Em desenvolvimento";


                    if (
                        precisao >= 80
                    ) {

                        status =
                            "dominado";

                        texto =
                            "Bom domínio";

                    }

                    else if (
                        precisao < 50
                    ) {

                        status =
                            "revisar";

                        texto =
                            "Revisar";

                    }


                    return `

                        <div class="conceito-final">

                            <div class="conceito-final-info">

                                <strong>
                                    ${escaparHTML(
                                        conceito
                                    )}
                                </strong>

                                <span>
                                    ${dados.acertos}
                                    acerto(s) ·
                                    ${dados.erros}
                                    erro(s) ·
                                    ${precisao}%
                                </span>

                            </div>

                            <div
                                class="conceito-final-status ${status}"
                            >
                                ${texto}
                            </div>

                        </div>

                    `;

                }
            )
            .join("");

}


// ============================================================
// MATERIAIS FINAIS
// ============================================================

function renderizarMateriaisFinais() {

    if (
        arquivosSelecionados.length === 0
    ) {

        finalMateriaisLista.innerHTML = `

            <div class="final-material">
                Nenhum arquivo foi enviado.
            </div>

        `;

        return;
    }


    finalMateriaisLista.innerHTML =
        arquivosSelecionados
            .map(
                arquivo => {

                    return `

                        <div class="final-material">
                            ${escaparHTML(
                                arquivo.name
                            )}
                        </div>

                    `;

                }
            )
            .join("");

}


// ============================================================
// TERMINAR
// ============================================================

function terminarSessao() {

    clearInterval(
        intervaloCronometro
    );


    sessao.classList.add(
        "escondida"
    );


    telaFinal.classList.remove(
        "escondida"
    );


    const total =
        acertos + erros;


    const precisao =
        total === 0
            ? 0
            : Math.round(
                (acertos /
                    total) *
                    100
            );


    finalAcertos.textContent =
        acertos;


    finalErros.textContent =
        erros;


    finalPrecisao.textContent =
        `${precisao}%`;


    renderizarDiagnosticoFinal();

    renderizarMateriaisFinais();

}


// ============================================================
// NOVA SESSÃO
// ============================================================

novaSessao.addEventListener(
    "click",
    () => {

        clearInterval(
            intervaloCronometro
        );


        telaFinal.classList.add(
            "escondida"
        );


        sessao.classList.add(
            "escondida"
        );


        preparacao.classList.add(
            "escondida"
        );


        inicio.classList.remove(
            "escondida"
        );


        materiaInput.value =
            "";


        objetivoInput.value =
            "";


        arquivosSelecionados = [];


        renderizarArquivos();


        tempoSelecionado =
            30;


        document
            .querySelectorAll(
                ".tempo"
            )
            .forEach(botao => {

                botao.classList.remove(
                    "ativo"
                );

            });


        document
            .querySelector(
                '.tempo[data-tempo="30"]'
            )
            .classList.add(
                "ativo"
            );

    }
);


// ============================================================
// ESTADO INICIAL
// ============================================================

renderizarArquivos();

questoesTotal.textContent =
    questoes.length;

atualizarDesempenho();

renderizarHistorico();


// ============================================================
// LOG
// ============================================================

console.log(
    "Sessão Guiada V3 carregada."
);
