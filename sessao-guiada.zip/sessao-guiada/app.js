/* =========================================
   SESSÃO GUIADA
========================================= */

/* =========================================
   CONFIGURAÇÕES
========================================= */

let tempoSelecionado = 30;
let tempoInicial = 30 * 60;
let tempoRestante = 30 * 60;

let intervaloCronometro = null;

let questaoAtual = 0;
let respostaSelecionada = null;
let respondida = false;

let acertos = 0;
let erros = 0;

let modoSelecionado = "ia";

let arquivosSelecionados = [];

let materialAnalisado = null;

let historicoDecisoes = [];

let desempenhoConceitos = {};


/* =========================================
   QUESTÕES DEMONSTRATIVAS
========================================= */

const questoesDemonstrativas = [

    {
        pergunta: "Qual é o resultado de 2x + 4 quando x = 3?",

        alternativas: [
            "A) 6",
            "B) 8",
            "C) 10",
            "D) 12"
        ],

        correta: 2,

        conceito: "Substituição de valores",

        dificuldade: "Fácil",

        tipo: "DIAGNÓSTICO",

        explicacao:
            "Substituindo x por 3: 2 × 3 + 4 = 6 + 4 = 10."
    },

    {
        pergunta: "Se f(x) = x², qual é o valor de f(4)?",

        alternativas: [
            "A) 8",
            "B) 12",
            "C) 16",
            "D) 20"
        ],

        correta: 2,

        conceito: "Funções",

        dificuldade: "Fácil",

        tipo: "APLICAÇÃO",

        explicacao:
            "Como f(x) = x², temos f(4) = 4² = 16."
    },

    {
        pergunta: "Qual é a derivada de f(x) = x²?",

        alternativas: [
            "A) x",
            "B) 2x",
            "C) x²",
            "D) 2"
        ],

        correta: 1,

        conceito: "Derivadas",

        dificuldade: "Médio",

        tipo: "APLICAÇÃO",

        explicacao:
            "Pela regra da potência, a derivada de x² é 2x."
    },

    {
        pergunta: "Qual é o resultado de 5 × 6?",

        alternativas: [
            "A) 20",
            "B) 25",
            "C) 30",
            "D) 35"
        ],

        correta: 2,

        conceito: "Multiplicação",

        dificuldade: "Fácil",

        tipo: "VERIFICAÇÃO",

        explicacao:
            "Cinco grupos de seis unidades totalizam 30."
    },

    {
        pergunta: "Se x + 7 = 12, qual é o valor de x?",

        alternativas: [
            "A) 3",
            "B) 4",
            "C) 5",
            "D) 6"
        ],

        correta: 2,

        conceito: "Equação de primeiro grau",

        dificuldade: "Médio",

        tipo: "VERIFICAÇÃO",

        explicacao:
            "Subtraindo 7 dos dois lados: x = 12 - 7 = 5."
    }

];


/*
   QUESTÕES QUE SERÃO USADAS NA SESSÃO
*/

let questoes = questoesDemonstrativas;


/* =========================================
   ELEMENTOS HTML
========================================= */

const $ = id => document.getElementById(id);

const homeScreen = $("homeScreen");
const analysisScreen = $("analysisScreen");
const sessionScreen = $("sessionScreen");
const resultScreen = $("resultScreen");

const objectiveInput = $("objective");
const pdfInput = $("pdfInput");
const uploadArea = $("uploadArea");
const fileInfo = $("fileInfo");

const homeError = $("homeError");

const startButton = $("startButton");
const finishButton = $("finishButton");
const newSessionButton = $("newSessionButton");

const timer = $("timer");
const headerTimer = $("headerTimer");
const timeBar = $("timeBar");
const timeMessage = $("timeMessage");

const progressBar = $("progressBar");
const progressPercent = $("progressPercent");
const questionCount = $("questionCount");

const accuracy = $("accuracy");
const correctCount = $("correctCount");
const wrongCount = $("wrongCount");

const currentConcept = $("currentConcept");
const conceptStatus = $("conceptStatus");

const historyList = $("historyList");

const sessionObjective = $("sessionObjective");
const sessionMode = $("sessionMode");

const decisionText = $("decisionText");

const difficultyBadge = $("difficultyBadge");

const questionNumber = $("questionNumber");
const questionTitle = $("questionTitle");
const questionText = $("questionText");

const answers = $("answers");

const feedback = $("feedback");

const answerButton = $("answerButton");
const continueButton = $("continueButton");

const materialName = $("materialName");
const materialExcerpt = $("materialExcerpt");
const toggleMaterial = $("toggleMaterial");

const resultReason = $("resultReason");
const resultCorrect = $("resultCorrect");
const resultWrong = $("resultWrong");
const resultAccuracy = $("resultAccuracy");


/* =========================================
   TEMA CLARO E ESCURO
========================================= */

const themeToggle = $("themeToggle");
const sessionThemeToggle = $("sessionThemeToggle");

const themeIcon = $("themeIcon");
const themeText = $("themeText");
const sessionThemeIcon = $("sessionThemeIcon");

let temaAtual = localStorage.getItem("sessao-tema");

if (temaAtual !== "dark" && temaAtual !== "light") {

    temaAtual = "light";

}

function aplicarTema(tema) {

    document.documentElement.setAttribute(
        "data-theme",
        tema
    );

    temaAtual = tema;

    const escuro = tema === "dark";

    themeIcon.textContent =
        escuro ? "🌙" : "☀️";

    themeText.textContent =
        escuro
            ? "Modo escuro"
            : "Modo claro";

    sessionThemeIcon.textContent =
        escuro ? "🌙" : "☀️";

    themeToggle.setAttribute(
        "aria-label",
        escuro
            ? "Ativar modo claro"
            : "Ativar modo escuro"
    );

    sessionThemeToggle.setAttribute(
        "aria-label",
        escuro
            ? "Ativar modo claro"
            : "Ativar modo escuro"
    );

    localStorage.setItem(
        "sessao-tema",
        tema
    );
}

function alternarTema() {

    aplicarTema(
        temaAtual === "light"
            ? "dark"
            : "light"
    );

}

themeToggle.addEventListener(
    "click",
    alternarTema
);

sessionThemeToggle.addEventListener(
    "click",
    alternarTema
);

aplicarTema(temaAtual);


/* =========================================
   MODOS DE ESTUDO
========================================= */

document
    .querySelectorAll(".study-mode")
    .forEach(botao => {

        botao.addEventListener(
            "click",
            () => {

                document
                    .querySelectorAll(".study-mode")
                    .forEach(item => {

                        item.classList.remove(
                            "active"
                        );

                    });

                botao.classList.add(
                    "active"
                );

                modoSelecionado =
                    botao.dataset.mode;

                $("modeDescription").textContent =

                    modoSelecionado === "ia"

                        ? "🤖 Modo IA selecionado. A IA analisará o conteúdo do PDF e criará as questões."

                        : "⚡ Modo Normal selecionado. O sistema analisará o conteúdo do PDF sem utilizar IA.";

            }
        );

    });


/* =========================================
   SELEÇÃO DE TEMPO
========================================= */

document
    .querySelectorAll(".time-option")
    .forEach(botao => {

        botao.addEventListener(
            "click",
            () => {

                document
                    .querySelectorAll(".time-option")
                    .forEach(item => {

                        item.classList.remove(
                            "active"
                        );

                    });

                botao.classList.add(
                    "active"
                );

                tempoSelecionado =
                    Number(
                        botao.dataset.time
                    );

            }
        );

    });


/* =========================================
   SEGURANÇA HTML
========================================= */

function escaparHTML(texto) {

    return String(texto)

        .replace(/&/g, "&amp;")

        .replace(/</g, "&lt;")

        .replace(/>/g, "&gt;")

        .replace(/"/g, "&quot;")

        .replace(/'/g, "&#039;");

}


/* =========================================
   FORMATAÇÃO DE ARQUIVOS
========================================= */

function formatarTamanho(bytes) {

    if (bytes < 1024) {

        return bytes + " B";

    }

    if (bytes < 1024 * 1024) {

        return (
            (bytes / 1024).toFixed(1) +
            " KB"
        );

    }

    return (
        (bytes / (1024 * 1024)).toFixed(1) +
        " MB"
    );

}


/* =========================================
   UPLOAD DE PDF
========================================= */

pdfInput.addEventListener(
    "change",
    () => {

        adicionarArquivos(
            Array.from(pdfInput.files)
        );

        pdfInput.value = "";

    }
);


function adicionarArquivos(
    novosArquivos
) {

    novosArquivos.forEach(
        arquivo => {

            if (
                arquivo.type !==
                "application/pdf"
            ) {

                return;

            }

            const existe =
                arquivosSelecionados.some(
                    item =>
                        item.name ===
                        arquivo.name &&
                        item.size ===
                        arquivo.size
                );

            if (!existe) {

                arquivosSelecionados.push(
                    arquivo
                );

            }

        }
    );

    renderizarArquivos();

}


uploadArea.addEventListener(
    "dragover",
    evento => {

        evento.preventDefault();

        uploadArea.classList.add(
            "dragging"
        );

    }
);


uploadArea.addEventListener(
    "dragleave",
    () => {

        uploadArea.classList.remove(
            "dragging"
        );

    }
);


uploadArea.addEventListener(
    "drop",
    evento => {

        evento.preventDefault();

        uploadArea.classList.remove(
            "dragging"
        );

        adicionarArquivos(
            Array.from(
                evento.dataTransfer.files
            )
        );

    }
);


/* =========================================
   MOSTRAR ARQUIVOS
========================================= */

function renderizarArquivos() {

    if (
        arquivosSelecionados.length === 0
    ) {

        fileInfo.classList.add(
            "hidden"
        );

        fileInfo.innerHTML = "";

        return;

    }

    fileInfo.classList.remove(
        "hidden"
    );

    fileInfo.innerHTML =
        arquivosSelecionados

            .map(
                (arquivo, index) => `

                    <div class="file-item">

                        <div>

                            <div class="file-name">

                                📄 ${escaparHTML(
                                    arquivo.name
                                )}

                            </div>

                            <small>

                                ${formatarTamanho(
                                    arquivo.size
                                )}

                            </small>

                        </div>

                        <button
                            class="remove-file"
                            data-index="${index}"
                            type="button"
                            aria-label="Remover arquivo"
                        >

                            ×

                        </button>

                    </div>

                `
            )

            .join("");


    document
        .querySelectorAll(".remove-file")
        .forEach(botao => {

            botao.addEventListener(
                "click",
                () => {

                    const index =
                        Number(
                            botao.dataset.index
                        );

                    arquivosSelecionados.splice(
                        index,
                        1
                    );

                    renderizarArquivos();

                }
            );

        });

}


/* =========================================
   TROCAR DE TELA
========================================= */

function mostrarTela(tela) {

    [
        homeScreen,
        analysisScreen,
        sessionScreen,
        resultScreen
    ]

        .forEach(item => {

            item.classList.add(
                "hidden"
            );

        });

    tela.classList.remove(
        "hidden"
    );

    window.scrollTo({

        top: 0,

        behavior: "smooth"

    });

}


/* =========================================
   INICIAR PREPARAÇÃO
========================================= */

startButton.addEventListener(
    "click",
    iniciarPreparacao
);


async function iniciarPreparacao() {

    const objetivo =
        objectiveInput.value.trim();

    homeError.classList.add(
        "hidden"
    );


    if (!objetivo) {

        homeError.textContent =
            "Digite qual é o seu objetivo de estudo.";

        homeError.classList.remove(
            "hidden"
        );

        objectiveInput.focus();

        return;

    }


    if (
        arquivosSelecionados.length === 0
    ) {

        homeError.textContent =
            "Envie pelo menos um PDF para iniciar a análise do material.";

        homeError.classList.remove(
            "hidden"
        );

        return;

    }


    questaoAtual = 0;

    respostaSelecionada = null;

    respondida = false;

    acertos = 0;

    erros = 0;

    historicoDecisoes = [];

    desempenhoConceitos = {};

    materialAnalisado = null;

    tempoInicial =
        tempoSelecionado * 60;

    tempoRestante =
        tempoInicial;


    mostrarTela(
        analysisScreen
    );


    $("loadingText").textContent =
        "Enviando seu material para análise...";


    try {

        const questoesGeradas = [];

        let primeiroMaterial = null;


        for (
            let i = 0;
            i < arquivosSelecionados.length;
            i++
        ) {

            const arquivo =
                arquivosSelecionados[i];


            $("loadingText").textContent =
                `Analisando material ${i + 1} de ${arquivosSelecionados.length}: ${arquivo.name}`;


            const formulario =
                new FormData();


            formulario.append(
                "arquivo",
                arquivo
            );


            /*
               MODO IA
               Não usamos mais o nome do provedor
               no frontend.
            */

            formulario.append(
                "modo",
                modoSelecionado === "ia"
                    ? "ia"
                    : "normal"
            );


            const resposta =
                await fetch(
                    "http://localhost:3000/api/analisar-material",
                    {

                        method: "POST",

                        body: formulario

                    }
                );


            let dados;

            try {

                dados =
                    await resposta.json();

            } catch {

                throw new Error(
                    "O servidor não retornou uma resposta JSON válida."
                );

            }


            if (
                !resposta.ok ||
                !dados.sucesso
            ) {

                throw new Error(
                    dados.erro ||
                    "Não foi possível analisar o PDF."
                );

            }


            const material =
                dados.material;


            if (
                !material ||
                !Array.isArray(
                    material.topicos
                )
            ) {

                throw new Error(
                    "O servidor não retornou tópicos válidos."
                );

            }


            if (!primeiroMaterial) {

                primeiroMaterial =
                    material;

            }


            material.topicos.forEach(
                topico => {

                    if (
                        !Array.isArray(
                            topico.questoes
                        )
                    ) {

                        return;

                    }


                    topico.questoes.forEach(
                        questao => {

                            if (
                                !questao.pergunta ||
                                !Array.isArray(
                                    questao.alternativas
                                ) ||
                                questao.alternativas.length < 2
                            ) {

                                return;

                            }


                            let respostaCorreta =
                                Number(
                                    questao.respostaCorreta
                                );


                            if (
                                Number.isNaN(
                                    respostaCorreta
                                ) ||
                                respostaCorreta < 0 ||
                                respostaCorreta >=
                                    questao.alternativas.length
                            ) {

                                respostaCorreta = 0;

                            }


                            questoesGeradas.push({

                                pergunta:
                                    questao.pergunta,

                                alternativas:
                                    questao.alternativas,

                                correta:
                                    respostaCorreta,

                                conceito:
                                    topico.titulo ||
                                    "Conteúdo do PDF",

                                dificuldade:
                                    questao.dificuldade ||
                                    "Médio",

                                tipo:
                                    material.modo ===
                                    "ia"
                                        ? "IA"
                                        : "MATERIAL",

                                explicacao:
                                    questao.explicacao ||
                                    topico.resumo ||
                                    "Revise o conteúdo do material para compreender esta questão."

                            });

                        }
                    );

                }
            );

        }


        if (
            questoesGeradas.length === 0
        ) {

            throw new Error(
                "O PDF foi lido, mas nenhuma questão válida foi encontrada."
            );

        }


        /*
           SUBSTITUI AS QUESTÕES
           DEMONSTRATIVAS
        */

        questoes =
            questoesGeradas;


        materialAnalisado =
            primeiroMaterial;


        $("loadingText").textContent =
            `${questoes.length} questões foram preparadas com base no seu material.`;


        setTimeout(
            () => {

                iniciarSessao();

            },
            800
        );


    } catch (erro) {

        console.error(
            "Erro ao analisar PDF:",
            erro
        );


        mostrarTela(
            homeScreen
        );


        homeError.textContent =
            "Erro ao analisar o material: " +
            erro.message;


        homeError.classList.remove(
            "hidden"
        );

    }

}


/* =========================================
   INICIAR SESSÃO
========================================= */

function iniciarSessao() {

    mostrarTela(
        sessionScreen
    );


    sessionObjective.textContent =
        objectiveInput.value.trim();


    sessionMode.textContent =
        modoSelecionado === "ia"
            ? "🤖 MODO IA"
            : "⚡ MODO NORMAL";


    materialName.textContent =
        arquivosSelecionados
            .map(
                arquivo =>
                    arquivo.name
            )
            .join(", ");


    if (
        materialAnalisado &&
        Array.isArray(
            materialAnalisado.topicos
        )
    ) {

        materialExcerpt.textContent =
            materialAnalisado.topicos

                .map(
                    topico => {

                        return (

                            `${topico.titulo}\n\n` +

                            (
                                topico.resumo ||
                                topico.conteudo ||
                                ""
                            )

                        );

                    }
                )

                .join(
                    "\n\n--------------------\n\n"
                );

    } else {

        materialExcerpt.textContent =
            "Nenhum conteúdo foi analisado.";

    }


    atualizarCronometro();

    atualizarDesempenho();

    renderizarHistorico();

    carregarQuestao();


    adicionarHistorico(

        "acao",

        "Sessão iniciada",

        `O sistema preparou ${questoes.length} questões com base no material enviado.`

    );


    iniciarCronometro();

}


/* =========================================
   CARREGAR QUESTÃO
========================================= */

function carregarQuestao() {

    if (
        questaoAtual >=
        questoes.length
    ) {

        terminarSessao(
            "Você concluiu todas as questões!"
        );

        return;

    }


    const questao =
        questoes[questaoAtual];


    respostaSelecionada = null;

    respondida = false;


    questionTitle.textContent =
        "Analise a questão";


    questionText.textContent =
        questao.pergunta;


    difficultyBadge.textContent =
        String(
            questao.dificuldade ||
            "Médio"
        ).toUpperCase();


    questionNumber.textContent =
        `QUESTÃO ${questaoAtual + 1}`;


    currentConcept.textContent =
        questao.conceito ||
        "Conteúdo do PDF";


    conceptStatus.textContent =
        "Em avaliação";


    decisionText.textContent =

        questaoAtual === 0

            ? "Vamos começar pelo diagnóstico para identificar seu nível de conhecimento."

            : "Responda à questão para que o sistema avalie seu desempenho.";


    atualizarProgresso();


    answers.innerHTML = "";


    questao.alternativas.forEach(
        (texto, index) => {

            const botao =
                document.createElement(
                    "button"
                );

            botao.type = "button";

            botao.className =
                "answer-option";


            const letra =
                document.createElement(
                    "span"
                );

            letra.className =
                "answer-letter";

            letra.textContent =
                String.fromCharCode(
                    65 + index
                );


            const conteudo =
                document.createElement(
                    "span"
                );


            /*
               Remove A), B), C) ou D)
               caso o backend já tenha enviado
               a letra.
            */

            conteudo.textContent =
                String(texto).replace(
                    /^[A-D]\)\s*/i,
                    ""
                );


            botao.appendChild(
                letra
            );

            botao.appendChild(
                conteudo
            );


            botao.addEventListener(
                "click",
                () => {

                    selecionarAlternativa(
                        index,
                        botao
                    );

                }
            );


            answers.appendChild(
                botao
            );

        }
    );


    feedback.className =
        "feedback hidden";

    feedback.textContent =
        "";


    continueButton.classList.add(
        "hidden"
    );

    answerButton.classList.remove(
        "hidden"
    );


    answerButton.disabled =
        true;


    answerButton.textContent =
        "Confirmar resposta →";

}


/* =========================================
   SELECIONAR ALTERNATIVA
========================================= */

function selecionarAlternativa(
    index,
    botao
) {

    if (respondida) {

        return;

    }


    respostaSelecionada =
        index;


    document
        .querySelectorAll(
            ".answer-option"
        )
        .forEach(item => {

            item.classList.remove(
                "selected"
            );

        });


    botao.classList.add(
        "selected"
    );


    answerButton.disabled =
        false;

}


/* =========================================
   RESPONDER
========================================= */

answerButton.addEventListener(
    "click",
    avaliarResposta
);


function avaliarResposta() {

    if (
        respostaSelecionada === null ||
        respondida
    ) {

        return;

    }


    respondida = true;


    const questao =
        questoes[questaoAtual];


    const acertou =
        respostaSelecionada ===
        questao.correta;


    if (
        !desempenhoConceitos[
            questao.conceito
        ]
    ) {

        desempenhoConceitos[
            questao.conceito
        ] = {

            acertos: 0,

            erros: 0

        };

    }


    const botoes =
        document.querySelectorAll(
            ".answer-option"
        );


    if (
        botoes[questao.correta]
    ) {

        botoes[
            questao.correta
        ].classList.add(
            "correct"
        );

    }


    botoes.forEach(
        botao => {

            botao.disabled =
                true;

        }
    );


    if (acertou) {

        acertos++;


        desempenhoConceitos[
            questao.conceito
        ].acertos++;


        conceptStatus.textContent =
            "Conceito demonstrado";


        feedback.className =
            "feedback correct";


        feedback.innerHTML =
            `<strong>✓ Resposta correta!</strong><br>${escaparHTML(
                questao.explicacao
            )}`;


        decisionText.textContent =
            "Seu resultado foi positivo. O sistema decidiu avançar.";


        adicionarHistorico(

            "correct",

            `Questão ${questaoAtual + 1} · Acertou`,

            `${questao.conceito} demonstrado.`

        );

    } else {

        erros++;


        desempenhoConceitos[
            questao.conceito
        ].erros++;


        if (
            botoes[respostaSelecionada]
        ) {

            botoes[
                respostaSelecionada
            ].classList.add(
                "wrong"
            );

        }


        conceptStatus.textContent =
            "Precisa de revisão";


        feedback.className =
            "feedback wrong";


        feedback.innerHTML =
            `<strong>✕ Resposta incorreta.</strong><br>${escaparHTML(
                questao.explicacao
            )}`;


        decisionText.textContent =
            "O sistema identificou uma dificuldade. Revise a explicação antes de continuar.";


        adicionarHistorico(

            "wrong",

            `Questão ${questaoAtual + 1} · Errou`,

            `${questao.conceito} precisa de revisão.`

        );

    }


    atualizarDesempenho();

    atualizarProgresso();


    answerButton.classList.add(
        "hidden"
    );


    continueButton.classList.remove(
        "hidden"
    );

}


/* =========================================
   CONTINUAR
========================================= */

continueButton.addEventListener(
    "click",
    () => {

        questaoAtual++;

        carregarQuestao();

    }
);


/* =========================================
   PROGRESSO
========================================= */

function atualizarProgresso() {

    const total =
        questoes.length;


    const respondidas =
        acertos + erros;


    const porcentagem =
        total === 0

            ? 0

            : Math.round(
                (respondidas / total) *
                100
            );


    progressBar.style.width =
        `${porcentagem}%`;


    progressPercent.textContent =
        `${porcentagem}%`;


    questionCount.textContent =
        respondidas;

}


/* =========================================
   DESEMPENHO
========================================= */

function atualizarDesempenho() {

    correctCount.textContent =
        acertos;

    wrongCount.textContent =
        erros;


    const total =
        acertos + erros;


    const precisao =
        total === 0

            ? 0

            : Math.round(
                (acertos / total) *
                100
            );


    accuracy.textContent =
        `${precisao}%`;

}


/* =========================================
   HISTÓRICO
========================================= */

function adicionarHistorico(
    tipo,
    titulo,
    descricao
) {

    historicoDecisoes.unshift({

        tipo,

        titulo,

        descricao

    });


    renderizarHistorico();

}


function renderizarHistorico() {

    if (
        historicoDecisoes.length === 0
    ) {

        historyList.innerHTML = `

            <div class="empty-history">

                As decisões aparecerão aqui.

            </div>

        `;

        return;

    }


    historyList.innerHTML =
        historicoDecisoes

            .slice(0, 8)

            .map(
                item => {

                    const classe =

                        item.tipo ===
                        "correct"

                            ? "correct"

                            : item.tipo ===
                              "wrong"

                                ? "wrong"

                                : "";


                    return `

                        <div class="history-item ${classe}">

                            <strong>
                                ${escaparHTML(
                                    item.titulo
                                )}
                            </strong>

                            <span>
                                ${escaparHTML(
                                    item.descricao
                                )}
                            </span>

                        </div>

                    `;

                }
            )

            .join("");

}


/* =========================================
   CRONÔMETRO
========================================= */

function iniciarCronometro() {

    clearInterval(
        intervaloCronometro
    );


    intervaloCronometro =
        setInterval(
            () => {

                tempoRestante--;

                atualizarCronometro();


                if (
                    tempoRestante <= 0
                ) {

                    clearInterval(
                        intervaloCronometro
                    );


                    terminarSessao(
                        "O tempo da sua sessão terminou."
                    );

                }

            },
            1000
        );

}


function atualizarCronometro() {

    const minutos =
        Math.floor(
            tempoRestante / 60
        );


    const segundos =
        tempoRestante % 60;


    const texto =
        `${String(minutos).padStart(2, "0")}:${String(segundos).padStart(2, "0")}`;


    timer.textContent =
        texto;


    headerTimer.textContent =
        texto;


    const porcentagem =
        Math.max(
            0,
            (tempoRestante /
                tempoInicial) *
                100
        );


    timeBar.style.width =
        `${porcentagem}%`;


    if (
        porcentagem <= 25
    ) {

        timeMessage.textContent =
            "Pouco tempo restante. Concentre-se nas questões.";

        timeBar.style.background =
            "#dc2626";

    } else if (
        porcentagem <= 50
    ) {

        timeMessage.textContent =
            "Metade da sessão já passou.";

        timeBar.style.background =
            "#f59e0b";

    } else {

        timeMessage.textContent =
            "Você está no início da sessão.";

        timeBar.style.background =
            "#635bff";

    }

}


/* =========================================
   MATERIAL
========================================= */

toggleMaterial.addEventListener(
    "click",
    () => {

        materialExcerpt.classList.toggle(
            "hidden"
        );


        toggleMaterial.textContent =

            materialExcerpt.classList.contains(
                "hidden"
            )

                ? "Ver trecho"

                : "Ocultar trecho";

    }
);


/* =========================================
   ENCERRAR SESSÃO
========================================= */

finishButton.addEventListener(
    "click",
    () => {

        terminarSessao(
            "Você encerrou a sessão manualmente."
        );

    }
);


function terminarSessao(
    motivo
) {

    clearInterval(
        intervaloCronometro
    );


    const total =
        acertos + erros;


    const precisao =
        total === 0

            ? 0

            : Math.round(
                (acertos / total) *
                100
            );


    resultCorrect.textContent =
        acertos;


    resultWrong.textContent =
        erros;


    resultAccuracy.textContent =
        `${precisao}%`;


    resultReason.textContent =
        motivo;


    mostrarTela(
        resultScreen
    );

}


/* =========================================
   NOVA SESSÃO
========================================= */

newSessionButton.addEventListener(
    "click",
    () => {

        clearInterval(
            intervaloCronometro
        );


        questaoAtual = 0;

        respostaSelecionada = null;

        respondida = false;

        acertos = 0;

        erros = 0;


        historicoDecisoes = [];

        desempenhoConceitos = {};


        arquivosSelecionados = [];

        materialAnalisado = null;


        /*
           RESTAURA AS QUESTÕES
           DEMONSTRATIVAS
        */

        questoes =
            questoesDemonstrativas;


        tempoSelecionado = 30;

        tempoInicial =
            30 * 60;

        tempoRestante =
            tempoInicial;


        objectiveInput.value = "";

        pdfInput.value = "";


        document
            .querySelectorAll(
                ".time-option"
            )
            .forEach(botao => {

                botao.classList.toggle(
                    "active",
                    botao.dataset.time ===
                    "30"
                );

            });


        document
            .querySelectorAll(
                ".study-mode"
            )
            .forEach(botao => {

                botao.classList.toggle(
                    "active",
                    botao.dataset.mode ===
                    "ia"
                );

            });


        modoSelecionado =
            "ia";


        /*
           Texto sem mencionar o provedor.
        */

        $("modeDescription").textContent =
            "🤖 Modo IA selecionado. A IA analisará o conteúdo do PDF e criará as questões.";


        renderizarArquivos();

        atualizarDesempenho();

        renderizarHistorico();

        mostrarTela(
            homeScreen
        );

    }
);


/* =========================================
   INICIALIZAÇÃO
========================================= */

renderizarArquivos();

atualizarDesempenho();

renderizarHistorico();


console.log(
    "Sessão Guiada carregada com sucesso."
);
